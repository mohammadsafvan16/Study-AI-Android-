# Study AI — Native Android starter

A native Kotlin + Jetpack Compose Android app (not a website/PWA). Includes Home, AI Tutor UI, Study Plans (add sessions and check them off), and a starter Notes screen.

## Important status
This is the first source-code scaffold, not a compiled APK. It needs a cloud build (or Android build environment), an AI backend deployment, and a configured backend URL before the live tutor can answer.

## Build an APK using only your Android phone
1. Create a GitHub account if you do not already have one.
2. Upload this project folder to a new GitHub repository (GitHub's mobile website/app can upload files; a browser-based GitHub Codespace is another option).
3. In `app/build.gradle.kts`, replace `https://YOUR-BACKEND.example.com/` in `AI_API_BASE_URL` with your deployed HTTPS backend URL, keeping the quotes.
4. Open the repository's **Actions** tab and run **Build Study AI APK** (or push to `main`).
5. Download the `StudyAI-debug-apk` artifact from the completed workflow, extract it on your phone, and install the APK. Android may ask you to allow installation from the app you used to open it.

## Configure the real AI tutor
1. Deploy the `backend` folder to a Node.js hosting service that supports environment variables and HTTPS.
2. Set `AI_API_KEY` on the hosting service. Optional: set `AI_API_URL`, `AI_MODEL`, and `PORT`.
3. The backend uses an OpenAI-compatible Chat Completions endpoint. Do not add the secret key to Kotlin, GitHub source, or the APK.
4. Set `AI_API_BASE_URL` in the Android Gradle config to the backend base URL, then rebuild.

## Current starter limitations
- Study plan items and notes are in-memory only and reset when the app process is restarted.
- Login, cloud sync, PDF upload/analysis, quizzes, and persistent progress tracking are not implemented yet.
- Add authentication, request limits, and abuse protection before making a public release. Keep API keys in backend environment variables.
