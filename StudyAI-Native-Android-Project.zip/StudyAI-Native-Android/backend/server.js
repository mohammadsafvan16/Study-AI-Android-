import express from 'express';
import cors from 'cors';
import 'dotenv/config';

const app = express();
app.use(cors());
app.use(express.json({ limit: '32kb' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Study AI tutor' }));
app.post('/api/tutor', async (req, res) => {
  const question = String(req.body?.question ?? '').trim();
  if (!question || question.length > 4000) return res.status(400).json({ error: 'Please send a question under 4000 characters.' });
  if (!process.env.AI_API_KEY) return res.status(503).json({ error: 'AI service is not configured.' });
  try {
    const upstream = await fetch(process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.AI_MODEL || 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are Study AI, a kind, age-appropriate study tutor. Explain concepts clearly, use step-by-step reasoning suitable for learning, encourage the student to try, and never request personal information. If asked about a dangerous topic, respond safely and redirect to learning.' },
          { role: 'user', content: question }
        ],
        temperature: 0.5
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'AI provider error.' });
    res.json({ answer: data.choices?.[0]?.message?.content ?? 'No answer was returned.' });
  } catch {
    res.status(502).json({ error: 'Could not contact the AI provider.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Study AI backend listening on ${port}`));
