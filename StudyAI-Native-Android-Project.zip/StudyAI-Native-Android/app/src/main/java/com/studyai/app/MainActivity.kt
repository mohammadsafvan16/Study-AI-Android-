package com.studyai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF151D33)
private val Purple = Color(0xFF8B7CFF)
private val Muted = Color(0xFFAAB4CC)
private val White = Color(0xFFF7F8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyAiApp() }
    }
}

@Composable
fun StudyAiApp() {
    var tab by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Ink, surface = Panel)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = White) {
                listOf("Home", "Tutor", "Plans", "Notes").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when (item) { "Home" -> Icons.Default.Home; "Tutor" -> Icons.Default.AutoAwesome; "Plans" -> Icons.Default.CalendarMonth; else -> Icons.Default.Description }, contentDescription = item) },
                        label = { Text(item) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, indicatorColor = Color(0xFF29264C), selectedTextColor = White, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Tutor" -> TutorScreen()
                    "Plans" -> PlansScreen()
                    "Notes" -> NotesScreen()
                    else -> HomeScreen(onTutor = { tab = "Tutor" }, onPlans = { tab = "Plans" })
                }
            }
        }
    }
}

@Composable
fun PageTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp)); Text(subtitle, color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun SurfaceCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp).background(Panel, RoundedCornerShape(20.dp)).padding(16.dp), content = content)
}

@Composable
fun HomeScreen(onTutor: () -> Unit, onPlans: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { PageTitle("Study smarter.", "Your personal AI-powered study space") }
        item { SurfaceCard {
            Text("WELCOME BACK", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp)); Text("Small steps. Big progress.", color = White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Text("Make today count with a focused study session.", color = Muted)
            Spacer(Modifier.height(14.dp)); Button(onClick = onTutor, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Ask your AI tutor") }
        } }
        item { SurfaceCard {
            Text("YOUR STUDY PLAN", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp)); Text("Plan your subjects, set goals and track each session.", color = Muted)
            TextButton(onClick = onPlans) { Text("Open study plans  →", color = Purple) }
        } }
        item { SurfaceCard {
            Text("QUICK TOOLS", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("AI Tutor", "Study Plans", "Smart Notes").forEach { Text(it, Modifier.weight(1f).background(Color(0xFF222B48), RoundedCornerShape(12.dp)).padding(10.dp), color = White, fontSize = 12.sp) }
            }
        } }
    }
}

@Composable
fun TutorScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Hi! I'm your Study AI tutor. Ask me to explain a topic, give an example, or guide you through a problem.") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        PageTitle("AI Tutor", "Ask questions and learn step by step")
        SurfaceCard { Text("YOUR TUTOR", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.height(8.dp)); Text(answer, color = White, lineHeight = 23.sp) }
        Spacer(Modifier.weight(1f))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Purple)
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = question, onValueChange = { question = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask a study question…") }, shape = RoundedCornerShape(16.dp), maxLines = 3)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                val q = question.trim(); if (q.isNotEmpty() && !loading) {
                    loading = true; question = ""
                    scope.launch { answer = askTutor(q); loading = false }
                }
            }, enabled = !loading) { Icon(Icons.Default.Send, "Send", tint = Purple) }
        }
        Text("AI responses can make mistakes. Check important facts with your textbook.", Modifier.padding(start = 18.dp, end = 18.dp, bottom = 8.dp), color = Muted, fontSize = 11.sp)
    }
}

private suspend fun askTutor(question: String): String = withContext(Dispatchers.IO) {
    try {
        val body = JSONObject().put("question", question).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url(BuildConfig.AI_API_BASE_URL.trimEnd('/') + "/api/tutor").post(body).build()
        OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext "The tutor service returned an error (${response.code}). Check your backend URL and server logs."
            JSONObject(response.body?.string().orEmpty()).optString("answer", "I couldn't read the tutor response.")
        }
    } catch (_: Exception) { "I can't reach the AI tutor yet. Deploy the backend and set AI_API_BASE_URL in app/build.gradle.kts, then rebuild the app." }
}

data class StudyTask(val subject: String, val topic: String, val duration: String)

@Composable
fun PlansScreen() {
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("30 min") }
    var tasks by remember { mutableStateOf(listOf(StudyTask("Mathematics", "Revise algebra basics", "30 min"), StudyTask("Science", "Review today's class notes", "25 min"))) }
    Column(Modifier.fillMaxSize()) {
        PageTitle("Study Plans", "Build a routine that works for you")
        SurfaceCard {
            Text("ADD A STUDY SESSION", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(subject, { subject = it }, Modifier.fillMaxWidth(), label = { Text("Subject") }, singleLine = true)
            Spacer(Modifier.height(8.dp)); OutlinedTextField(topic, { topic = it }, Modifier.fillMaxWidth(), label = { Text("What will you study?") }, singleLine = true)
            Spacer(Modifier.height(8.dp)); Text("Session length", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("15 min", "30 min", "45 min", "60 min").forEach { FilterChip(selected = duration == it, onClick = { duration = it }, label = { Text(it) }) } }
            Button(onClick = { if (subject.isNotBlank() && topic.isNotBlank()) { tasks = tasks + StudyTask(subject.trim(), topic.trim(), duration); subject = ""; topic = "" } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Add to my plan") }
        }
        Text("TODAY'S SESSIONS", Modifier.padding(start = 20.dp, top = 10.dp, bottom = 4.dp), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        LazyColumn { items(tasks) { task -> var done by remember(task) { mutableStateOf(false) }
            SurfaceCard { Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(done, { done = it }, colors = CheckboxDefaults.colors(checkedColor = Purple))
                Column(Modifier.weight(1f)) { Text(task.subject, color = White, fontWeight = FontWeight.SemiBold); Text(task.topic, color = Muted, fontSize = 13.sp) }
                Text(task.duration, color = Purple, fontSize = 12.sp)
            } }
        } }
    }
}

@Composable
fun NotesScreen() {
    var note by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        PageTitle("Smart Notes", "Keep useful ideas in one place")
        SurfaceCard { Text("QUICK NOTE", color = Purple, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().height(180.dp), placeholder = { Text("Write or paste your study notes here…") }); Text("Notes are currently kept on this screen only. Local saving and AI summaries can be added next.", color = Muted, fontSize = 12.sp) }
    }
}
